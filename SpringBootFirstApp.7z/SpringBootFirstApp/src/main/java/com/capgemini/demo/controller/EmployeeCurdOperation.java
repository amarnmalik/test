package com.capgemini.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.demo.beans.Employee;
import com.capgemini.demo.service.EmployeeService;

@RestController
public class EmployeeCurdOperation {
	
	private static List<Employee> empList;
	
	@Autowired
	private EmployeeService employeeService;
	
	@RequestMapping("/addEmployee")
	public List<Employee> addEmployee(@RequestBody Employee emp){
//		empList.add(emp);
		return employeeService.addEmployee(emp);
	}
	
	@PostMapping("/removeEmployee")
	public List<Employee> removeEmployee(@RequestParam String id) {
		empList.remove(empList.stream().filter(e -> id.equals(e.getId())).findFirst().get());
		return empList;
	}
	
	@RequestMapping("/update")
	public List<Employee> update(@RequestParam String id) {
		Employee emp = empList.stream().filter(e -> id.equals(e.getId())).findFirst().get());
		return null;
	}
	
	public Employee getEmployee() {
		return new Employee();
	}

	public static List<Employee> getEmpList() {
		return empList;
	}

	public static void setEmpList(List<Employee> empList) {
		EmployeeCurdOperation.empList = empList;
	}
}
