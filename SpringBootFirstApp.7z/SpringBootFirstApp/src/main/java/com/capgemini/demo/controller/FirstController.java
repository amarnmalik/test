package com.capgemini.demo.controller;

import java.util.Arrays;
import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.demo.beans.Employee;

@RestController
public class FirstController {

	List<Employee> empList;
	
	@RequestMapping("/")
	public String getHello() {
		return "Hello";
	}
	
	@GetMapping(value="/getEmployee/{name}", produces = { "application/json", "application/xml" })
//	public Employee getEmployee(@RequestParam String name) {
	public Employee getEmployee(@PathVariable String name) {
		addEmployee();
		Employee emp = empList.stream().filter(x -> name.equals(x.getName())).findFirst().get();
		return emp;
	}
	
	@RequestMapping(value="/getEmployeeList", produces = { "application/json", "application/xml"})
	public List<Employee> getEmployeeList() {
		addEmployee();
		return empList;
	}
	
	void addEmployee() {
		empList = Arrays.asList(new Employee("101", "amar"), new Employee("102", "akhbar"),	new Employee("103", "anthony"));
	}
}
