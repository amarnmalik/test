package com.capgemini.demo.service;

import java.util.Arrays;
import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestParam;

import com.capgemini.demo.beans.Employee;

@Service
public class EmployeeService {
	List<Employee> empList = Arrays.asList(new Employee("101", "amar"), new Employee("102", "akhbar"),	new Employee("103", "anthony"));
	
	public List<Employee> getEmployees() {
		return empList;
	}
	
	public List<Employee> addEmployee(Employee emp) {
		empList.add(emp);
		return empList;
	}
	
	public List<Employee> removeEmployee(@RequestParam String id) {
		empList.remove(empList.stream().filter(e -> id.equals(e.getId())).findFirst().get());
		
		return empList;
	}
}
