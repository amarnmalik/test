package com.capgemini;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ControllerServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(ControllerServiceApplication.class, args);
	}
}
