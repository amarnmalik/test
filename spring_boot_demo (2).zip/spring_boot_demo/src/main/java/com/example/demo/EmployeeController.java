package com.example.demo;

import java.util.ArrayList;
import java.util.NoSuchElementException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class EmployeeController {
	
	@Autowired
	EmployeeService employeeService;
	
	
	@RequestMapping("/")
	public String getHello() {
		return "Hello World";
	}
	
	@RequestMapping("/employees")
	public ArrayList<Employee> getAllEmploye() {
		return employeeService.getAllEmploye();
	}
	
	@RequestMapping("/employee/{id}")
	public Employee getEmploye(@PathVariable String id) {
		System.out.println(id);
		Employee ret = null;
		try {
			ret = employeeService.getAllEmploye().stream().filter(e -> e.getId().equals(id)).findFirst().get();
		} catch (NoSuchElementException ex){
			ex.printStackTrace();
		}
		if (null == ret) {
			throw new EmployeeNotFoundException("Not found Employee with id " + id);
		}
		return ret;
	}
	
	@RequestMapping(method=RequestMethod.DELETE,value="/delete/{id}")
	public boolean deleteEmploye(@PathVariable String id) {
		System.out.println(id);
		//return EmployeeService.list.remove(getEmploye(id));
		return employeeService.getAllEmploye().removeIf(t -> t.getId().equals(id));
	}
	
	@RequestMapping(method=RequestMethod.POST,value="/add")
	public boolean addEmployee(@RequestBody Employee e) {
		return employeeService.getAllEmploye().add(e);
	}
	
	@RequestMapping(method=RequestMethod.PUT,value="/update")
	public boolean updateEmployee(@RequestBody Employee e) {
		Employee oldEmp = getEmploye(e.getId());
		oldEmp.setName(e.getName());
        return true;
	}

}
