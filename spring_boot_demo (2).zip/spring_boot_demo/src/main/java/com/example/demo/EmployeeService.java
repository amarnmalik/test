package com.example.demo;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.annotation.PostConstruct;

import org.springframework.stereotype.Service;

@Service
public class EmployeeService {

//	public ArrayList<Employee> list = new ArrayList<Employee>(
//			Arrays.asList(new Employee("101","ABC"), new Employee("102","PQR"), new Employee("103","XYZ")));
	
	public ArrayList<Employee> list = null;
	
	@PostConstruct
	void init() {
		list = new ArrayList<Employee>(
				Arrays.asList(new Employee("101","ABC"), new Employee("102","PQR"), new Employee("103","XYZ")));
	}
	
	public String getHello() {
		return "Hello";
	}
	
	public ArrayList<Employee> getAllEmploye() {
		return list;
	}
	
	public Employee getEmploye(String id) {
		System.out.println(id);
		return list.stream().filter(e -> e.getId().equals(id)).findFirst().get();
	}
	
	public boolean deleteEmploye(String id) {
		System.out.println(id);
		//return EmployeeService.list.remove(getEmploye(id));
		return list.removeIf(t -> t.getId().equals(id));
	}
	
	public boolean addEmployee(Employee e) {
		return list.add(e);
	}
	
	public boolean updateEmployee(Employee e) {
		Employee oldEmp = getEmploye(e.getId());
		oldEmp.setName(e.getName());
        return true;
	}
}
